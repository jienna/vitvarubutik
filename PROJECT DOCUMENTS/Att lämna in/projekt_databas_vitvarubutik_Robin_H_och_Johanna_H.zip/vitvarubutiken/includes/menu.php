<nav>
  <a href="index.php">Hem</a> |
  <a href="customer_page.php">Kundsida</a> |
  <a href="admin_page.php">Administratörssida</a>
</nav>
