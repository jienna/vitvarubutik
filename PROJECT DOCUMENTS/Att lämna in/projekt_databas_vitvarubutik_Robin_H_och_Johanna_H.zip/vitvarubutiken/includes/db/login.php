<?php // login.php
$db_hostname = 'localhost';
$db_database = 'vitvarubutik';
$db_username = 'root';
$db_password = '';
$db_charset = "utf8";
?>
